﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace CureWellServices.Models
{
    public class Doctor
    {
        public int DoctorId { get; set; }
        public string DoctorName { get; set; }
    }
}
